const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');  
const db = require('./db');  
const app = express();
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.get('/', (req, res) => {   
    res.sendFile(path.join(__dirname, 'public', 'index.html')); 
});
app.post('/procesar-formulario', (req, res) => {
    console.log(req.body);
    const { nombre, correo, telefono, direccion, ciudad, codigo_postal, metodo_pago, cantidad, total } = req.body;
    const query = `INSERT INTO compras (nombre, correo, telefono, direccion, ciudad, codigo_postal, metodo_pago, cantidad, total)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`;
    db.query(query, [nombre, correo, telefono, direccion, ciudad, codigo_postal, metodo_pago, cantidad, total], (err, result) => {
        if (err) {
            console.error('Error al insertar el pedido: ', err.stack);
            res.status(500).send('Error al guardar los datos');
        } else {
            res.send('Compra realizada con éxito');
        }
    });
});
app.listen(3000, () => {
    console.log('Servidor corriendo en http://localhost:3000/');
});
