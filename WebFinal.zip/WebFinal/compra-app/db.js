const mysql = require('mysql2');
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',  
    password: '',  
    database: 'cafe_db'  
});
db.connect((err) => {
    if (err) {
        console.error('Error de conexión a la base de datos:', err.message);
        process.exit(1); 
    } else {
        console.log('Conexión a la base de datos exitosa');
    }
});
db.query('SELECT 1', (err, results) => {
    if (err) {
        console.error('Error al ejecutar consulta de prueba: ', err.stack);
    } else {
        console.log('Conexión de prueba exitosa');
    }
});
db.query('SHOW TABLES LIKE "compras"', (err, results) => {
    if (err) {
        console.error('Error al verificar la tabla compras:', err.message);
    } else if (results.length === 0) {
        console.warn('La tabla compras no existe.');
    } else {
        console.log('La tabla compras está disponible.');
    }
});
module.exports = db;
