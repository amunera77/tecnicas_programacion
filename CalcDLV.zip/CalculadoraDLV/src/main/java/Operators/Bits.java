/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Operators;

import static Util.Lectura.leerInt;
import java.io.IOException;

/**
 *
 * @author samue
 */
public class Bits {
    public static int and(String mensaje) throws IOException {
        int a = leerInt("Introduce el primer numero: ");
        int b = leerInt("Introduce el segundo numero: ");
        int and = a & b;
        System.out.println(and);
        return and;
    }

    public static int or(String mensaje) throws IOException {
        int a = leerInt("Introduce el primer numero: ");
        int b = leerInt("Introduce el segundo numero: ");
        int or = a | b;
        System.out.println(or);
        return or;
    }

    public static int xor(String mensaje) throws IOException {
        int a = leerInt("Introduce el primer numero: ");
        int b = leerInt("Introduce el segundo numero: ");
        int xor = a ^ b;
        System.out.println(xor);
        return xor;
    }

    public static int not(String mensaje) throws IOException {
        int a = leerInt("Introduce el numero: ");
        int not = ~a;
        System.out.println(not);
        return not;
    }

    public static int shiftLeft(String mensaje) throws IOException {
        int a = leerInt("Introduce el primer numero: ");
        int b = leerInt("Introduce el segundo numero: ");
        int shiftL = a << b;
        System.out.println(shiftL);
        return shiftL;
    }

    public static int shiftRight(String mensaje) throws IOException {
        int a = leerInt("Introduce el primer numero: ");
        int b = leerInt("Introduce el segundo numero: ");
        int shiftR = a >> b;
        System.out.println(shiftR);
        return shiftR;
    }

    public static int unsignedShiftRight(String mensaje) throws IOException {
        int a = leerInt("Introduce el primer numero: ");
        int b = leerInt("Introduce el segundo numero: ");
        int usr = a >>> b;
        System.out.println(usr);
        return usr;
    }
    
}
