/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Operators;

import static Util.Lectura.*;
import java.io.IOException;

/**
 *
 * @author samue
 */
public class arithmetic {

    public static int suma(String mensaje) throws IOException {
        int n1 = leerInt("Introduce el primer numero de la suma: ");
        int n2 = leerInt("Introduce el segundo numero de la suma: ");
        int suma = n1 + n2;
        System.out.println(suma);
        return suma;
    }

    public static int resta(String mensaje) throws IOException {
        int n1 = leerInt("Introduce el primer numero de la resta: ");
        int n2 = leerInt("Introduce el segundo numero de la resta: ");
        int resta = n1 - n2;
        System.out.println(resta);
        return resta;
    }

    public static int m(String mensaje) throws IOException {
        int n1 = leerInt("Introduce el primer numero de la multiplicacion: ");
        int n2 = leerInt("Introduce el segundo numero de la multiplicacion: ");
        int multiplicacion = n1 * n2;
        System.out.println(multiplicacion);
        return multiplicacion;
    }

    public static int division(String mensaje) throws IOException {
        int n1 = leerInt("Introduce el primer numero de la division: ");
        int n2 = leerInt("Introduce el segundo numero de la division: ");
        int division = n1 / n2;
        System.out.println(division);
        return division;
    }

    public static int modulo(String mensaje) throws IOException {
        int n1 = leerInt("Introduce el primer numero del modulo: ");
        int n2 = leerInt("Introduce el segundo numero del modulo: ");
        int modulo = n1 % n2;
        System.out.println(modulo);
        return modulo;
    }
}

