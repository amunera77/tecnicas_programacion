/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Operators;

import static Util.Lectura.leerBoolean;
import java.io.IOException;

/**
 *
 * @author samue
 */
public class BooleanOperations {

    public static boolean andOperation(String mensaje) throws IOException {
        boolean b1 = leerBoolean("Introduce el primer valor booleano (true/false): ");
        boolean b2 = leerBoolean("Introduce el segundo valor booleano (true/false): ");
        boolean resultado = b1 && b2;
        System.out.println("Resultado de AND: " + resultado);
        return resultado;
    }

    public static boolean orOperation(String mensaje) throws IOException {
        boolean b1 = leerBoolean("Introduce el primer valor booleano (true/false): ");
        boolean b2 = leerBoolean("Introduce el segundo valor booleano (true/false): ");
        boolean resultado = b1 || b2;
        System.out.println("Resultado de OR: " + resultado);
        return resultado;
    }

    public static boolean notOperation(String mensaje) throws IOException {
        boolean b1 = leerBoolean("Introduce el valor booleano (true/false): ");
        boolean resultado = !b1;
        System.out.println("Resultado de NOT: " + resultado);
        return resultado;
    }

    public static boolean equalsOperation(String mensaje) throws IOException {
        boolean b1 = leerBoolean("Introduce el primer valor booleano (true/false): ");
        boolean b2 = leerBoolean("Introduce el segundo valor booleano (true/false): ");
        boolean resultado = (b1 == b2);
        System.out.println("¿Son iguales?: " + resultado);
        return resultado;
    }

    public static boolean notEqualsOperation(String mensaje) throws IOException {
        boolean b1 = leerBoolean("Introduce el primer valor booleano (true/false): ");
        boolean b2 = leerBoolean("Introduce el segundo valor booleano (true/false): ");
        boolean resultado = (b1 != b2);
        System.out.println("¿Son diferentes?: " + resultado);
        return resultado;
    }
}
