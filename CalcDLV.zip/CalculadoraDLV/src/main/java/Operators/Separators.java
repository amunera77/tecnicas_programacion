/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Operators;

import static Util.Lectura.*;
import java.io.IOException;

/**
 *
 * @author samue
 */
public class Separators {

    public static void mostrarComas(String mensaje) throws IOException {
        int num1 = leerInt("Introduce el primer número: ");
        int num2 = leerInt("Introduce el segundo número: ");
        System.out.println("Los números introducidos son: " + num1 + ", " + num2);
    }

    public static void mostrarPuntoYComa(String mensaje) throws IOException {
        String str1 = leerString("Introduce la primera cadena: ");
        String str2 = leerString("Introduce la segunda cadena: ");
        System.out.println("Las cadenas introducidas son: " + str1 + "; " + str2);
    }

    public static void mostrarLlaves(String mensaje) throws IOException {
        int num1 = leerInt("Introduce un número: ");
        int num2 = leerInt("Introduce otro número: ");
        System.out.println("Números entre llaves: {" + num1 + ", " + num2 + "}");
    }

    public static void mostrarParentesis(String mensaje) throws IOException {
        int num1 = leerInt("Introduce un número: ");
        int num2 = leerInt("Introduce otro número: ");
        System.out.println("Números entre paréntesis: (" + num1 + ", " + num2 + ")");
    }

    public static void mostrarCorchetes(String mensaje) throws IOException {
        int num1 = leerInt("Introduce un número: ");
        int num2 = leerInt("Introduce otro número: ");
        System.out.println("Números entre corchetes: [" + num1 + ", " + num2 + "]");
    }
}
