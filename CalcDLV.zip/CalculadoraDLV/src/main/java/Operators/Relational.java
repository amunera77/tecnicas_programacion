/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Operators;

import static Util.Lectura.*;
import java.io.IOException;

/**
 *
 * @author samue
 */
public class Relational {
    public static boolean esMayor(String mensaje) throws IOException {
        int a = leerInt("Introduce el primer número: ");
        int b = leerInt("Introduce el segundo número: ");
        boolean result = a > b;
        System.out.println(result);
        return result;
    }

    public static boolean esMenor(String mensaje) throws IOException {
        int a = leerInt("Introduce el primer número: ");
        int b = leerInt("Introduce el segundo número: ");
        boolean result = a < b;
        System.out.println(result);
        return result;
    }

    public static boolean esMayorOIgual(String mensaje) throws IOException {
        int a = leerInt("Introduce el primer número: ");
        int b = leerInt("Introduce el segundo número: ");
        boolean result = a >= b;
        System.out.println(result);
        return result;
    }

    public static boolean esMenorOIgual(String mensaje) throws IOException {
        int a = leerInt("Introduce el primer número: ");
        int b = leerInt("Introduce el segundo número: ");
        boolean result = a <= b;
        System.out.println(result);
        return result;
    }

    public static boolean esIgual(String mensaje) throws IOException {
        int a = leerInt("Introduce el primer número: ");
        int b = leerInt("Introduce el segundo número: ");
        boolean result = a == b;
        System.out.println(result);
        return result;
    }

    public static boolean esDiferente(String mensaje) throws IOException {
        int a = leerInt("Introduce el primer número: ");
        int b = leerInt("Introduce el segundo número: ");
        boolean result = a != b;
        System.out.println(result);
        return result;
    }
}
