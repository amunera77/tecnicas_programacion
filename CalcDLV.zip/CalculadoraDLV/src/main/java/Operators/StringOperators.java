/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Operators;

import static Util.Lectura.*;
import java.io.IOException;

/**
 *
 * @author samue
 */
public class StringOperators {

    public static void concatenacion(String mensaje) throws IOException {
        String str1 = leerString("Introduce la primera cadena: ");
        String str2 = leerString("Introduce la segunda cadena: ");
        String resultado = str1 + str2;
        System.out.println("Resultado de la concatenación: " + resultado);
    }

    public static void comparacion(String mensaje) throws IOException {
        String str1 = leerString("Introduce la primera cadena: ");
        String str2 = leerString("Introduce la segunda cadena: ");
        boolean resultado = str1.equals(str2);
        System.out.println("Las cadenas son iguales: " + resultado);
    }

    public static void comparacionIgnoreCase(String mensaje) throws IOException {
        String str1 = leerString("Introduce la primera cadena: ");
        String str2 = leerString("Introduce la segunda cadena: ");
        boolean resultado = str1.equalsIgnoreCase(str2);
        System.out.println("Las cadenas son iguales ignorando mayúsculas/minúsculas: " + resultado);
    }
}

