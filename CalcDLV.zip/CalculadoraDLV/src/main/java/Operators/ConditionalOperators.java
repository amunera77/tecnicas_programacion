/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Operators;

import static Util.Lectura.*;
import java.io.IOException;

/**
 *
 * @author samue
 */
public class ConditionalOperators {

    public static void operadorTernario(String mensaje) throws IOException {
        int n1 = leerInt("Introduce el primer número: ");
        int n2 = leerInt("Introduce el segundo número: ");
        String resultado = (n1 > n2) ? "n1 es mayor que n2" : "n1 no es mayor que n2";
        System.out.println(resultado);
    }

    public static void operadorTernarioBooleano(String mensaje) throws IOException {
        boolean b1 = leerBoolean("Introduce el primer valor booleano (true/false): ");
        boolean b2 = leerBoolean("Introduce el segundo valor booleano (true/false): ");
        String resultado = (b1 && b2) ? "Ambos valores son verdaderos" : "Al menos uno de los valores es falso";
        System.out.println(resultado);
    }
}
