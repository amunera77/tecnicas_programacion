/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Operators;

import static Util.Lectura.*;
import java.io.IOException;

/**
 *
 * @author samue
 */
public class PriorityOperators {

    public static void prioridadSumaResta(String mensaje) throws IOException {
        int n1 = leerInt("Introduce el primer número: ");
        int n2 = leerInt("Introduce el segundo número: ");
        int n3 = leerInt("Introduce el tercer número: ");
        
        int resultado = (n1 + n2) - n3;
        System.out.println("Resultado de (n1 + n2) - n3: " + resultado);
    }

    public static void prioridadMultiplicacionDivision(String mensaje) throws IOException {
        int n1 = leerInt("Introduce el primer número: ");
        int n2 = leerInt("Introduce el segundo número: ");
        int n3 = leerInt("Introduce el tercer número: ");
        
        int resultado = (n1 * n2) / n3;
        System.out.println("Resultado de (n1 * n2) / n3: " + resultado);
    }

    public static void prioridadCombinada(String mensaje) throws IOException {
        int n1 = leerInt("Introduce el primer número: ");
        int n2 = leerInt("Introduce el segundo número: ");
        int n3 = leerInt("Introduce el tercer número: ");
        int n4 = leerInt("Introduce el cuarto número: ");
        
        int resultado = (n1 + (n2 * n3)) / n4;
        System.out.println("Resultado de (n1 + (n2 * n3)) / n4: " + resultado);
    }

    public static void prioridadParentesis(String mensaje) throws IOException {
        int n1 = leerInt("Introduce el primer número: ");
        int n2 = leerInt("Introduce el segundo número: ");
        int n3 = leerInt("Introduce el tercer número: ");
        
        int resultado = (n1 + n2) * n3;
        System.out.println("Resultado de (n1 + n2) * n3: " + resultado);
    }

    public static void prioridadCombinadaParentesis(String mensaje) throws IOException {
        int n1 = leerInt("Introduce el primer número: ");
        int n2 = leerInt("Introduce el segundo número: ");
        int n3 = leerInt("Introduce el tercer número: ");
        int n4 = leerInt("Introduce el cuarto número: ");
        
        int resultado = ((n1 + n2) * n3) / n4;
        System.out.println("Resultado de ((n1 + n2) * n3) / n4: " + resultado);
    }
}
