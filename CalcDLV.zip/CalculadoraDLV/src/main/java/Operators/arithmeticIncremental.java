/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Operators;

import static Util.Lectura.*;
import java.io.IOException;

/**
 *
 * @author samue
 */
public class arithmeticIncremental {

    public static int sumaIncremental(String mensaje) throws IOException {
        int n1 = leerInt("Introduce el primer número: ");
        int n2 = leerInt("Introduce el segundo número: ");
        int resultado = ++n1 + n2;
        System.out.println("Resultado de suma con pre-incremento: " + resultado);
        return resultado;
    }

    public static int restaDecremental(String mensaje) throws IOException {
        int n1 = leerInt("Introduce el primer número: ");
        int n2 = leerInt("Introduce el segundo número: ");
        int resultado = --n1 - n2;
        System.out.println("Resultado de resta con pre-decremento: " + resultado);
        return resultado;
    }

    public static int multiplicacionPostIncremental(String mensaje) throws IOException {
        int n1 = leerInt("Introduce el primer número: ");
        int n2 = leerInt("Introduce el segundo número: ");
        int resultado = n1++ * n2;
        System.out.println("Resultado de multiplicación con post-incremento: " + resultado);
        System.out.println("Valor de n1 después del post-incremento: " + n1);
        return resultado;
    }

    public static int divisionPostDecremental(String mensaje) throws IOException {
        int n1 = leerInt("Introduce el primer número: ");
        int n2 = leerInt("Introduce el segundo número: ");
        if (n2 == 0) {
            System.out.println("No se puede dividir por cero");
            return 0;
        }
        int resultado = n1-- / n2;
        System.out.println("Resultado de división con post-decremento: " + resultado);
        System.out.println("Valor de n1 después del post-decremento: " + n1);
        return resultado;
    }

    public static int moduloIncremental(String mensaje) throws IOException {
        int n1 = leerInt("Introduce el primer número: ");
        int n2 = leerInt("Introduce el segundo número: ");
        int resultado = ++n1 % n2;
        System.out.println("Resultado del módulo con pre-incremento: " + resultado);
        return resultado;
    }
}
