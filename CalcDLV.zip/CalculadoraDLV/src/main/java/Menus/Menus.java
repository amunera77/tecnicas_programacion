/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Menus;

import static Operators.Relational.*;
import static Operators.arithmetic.*;
import static Util.Lectura.*;
import static Operators.Bits.*;
import static Operators.BooleanOperations.*;
import static Operators.arithmeticIncremental.*;
import static Operators.ConditionalOperators.*;
import static Operators.StringOperators.*;
import static Operators.Separators.*;
import static Operators.PriorityOperators.*;
import java.io.IOException;

/**
 *
 * @author samue
 */
public class Menus {

    private static void printMenuHeader(String title) {
        System.out.println("====================================");
        System.out.println(title);
        System.out.println("====================================");
    }

    private static void printMenuFooter() {
        System.out.println("====================================");
    }

    public static double menuA(String mensaje) throws IOException {
        printMenuHeader("Operaciones Aritméticas");
        System.out.println("1: Suma");
        System.out.println("2: Resta");
        System.out.println("3: Multiplicación");
        System.out.println("4: División");
        System.out.println("5: Módulo");
        System.out.println("6: Volver al menú principal");
        printMenuFooter();
        
        double c = 0;
        String x = leerString("Elige una opción: ");
        switch (x) {
            case "1":
                suma("");
                break;
            case "2":
                resta("");
                break;
            case "3":
                m("");
                break;
            case "4":
                division("");
                break;
            case "5":
                modulo("");
                break;
            case "6":
                
                me("");
                break;
            default:
                System.out.println("Ingrese un número válido");
                c = menuA("");
                break;
        }
        return c;
    }

    public static double menuR(String mensaje) throws IOException {
        printMenuHeader("Operaciones Relacionales");
        System.out.println("1: Mayor que");
        System.out.println("2: Menor que");
        System.out.println("3: Mayor o igual que");
        System.out.println("4: Menor o igual que");
        System.out.println("5: Igual a");
        System.out.println("6: Diferente a");
         System.out.println("7: Volver al menú principal");
        printMenuFooter();
        
        double c = 0;
        String x = leerString("Elige una opción: ");
        switch (x) {
            case "1":
                esMayor("");
                break;
            case "2":
                esMenor("");
                break;
            case "3":
                esMayorOIgual("");
                break;
            case "4":
                esMenorOIgual("");
                break;
            case "5":
                esIgual("");
                break;
            case "6":
                esDiferente("");
                break;
            case "7":
                
                me("");
                break;
                 
            default:
                System.out.println("Ingrese un número válido");
                c = menuR("");
                break;
        }
        return c;
    }

    public static double menuB(String mensaje) throws IOException {
        printMenuHeader("Operaciones de Bits");
        System.out.println("1: AND");
        System.out.println("2: OR");
        System.out.println("3: XOR");
        System.out.println("4: NOT");
        System.out.println("5: Shift Left");
        System.out.println("6: Shift Right");
        System.out.println("7: Unsigned Shift Right");
         System.out.println("8: Volver al menú principal");
        printMenuFooter();
        
        double c = 0;
        String x = leerString("Elige una opción: ");
        switch (x) {
            case "1":
                and("");
                break;
            case "2":
                or("");
                break;
            case "3":
                xor("");
                break;
            case "4":
                not("");
                break;
            case "5":
                shiftLeft("");
                break;
            case "6":
                shiftRight("");
                break;
            case "7":
                unsignedShiftRight("");
                break;
            case "8":
                me("");
                break;
            default:
                System.out.println("Ingrese un número válido");
                c = menuB("");
                break;
        }
        return c;
    }

    public static double me(String mensaje) throws IOException {
        printMenuHeader("Menú Principal");
        System.out.println("1: Operación Aritmética");
        System.out.println("2: Operación Relacional");
        System.out.println("3: Operación de Bits");
        System.out.println("4: Operación de Booleanos");
        System.out.println("5: Operación Incremental y Aritmética Combinada");
        System.out.println("6: Operación Condicional");
        System.out.println("7: Operación de Cadenas");
        System.out.println("8: Operación de Separadores");
        System.out.println("9: Operación de Prioridad entre Operadores Aritméticos");
         System.out.println("10: Volver al menú principal");
        printMenuFooter();
        
        double c = 0;
        String x = leerString("Elige una opción: ");
        switch (x) {
            case "1":
                menuA("");
                break;
            case "2":
                menuR("");
                break;
            case "3":
                menuB("");
                break;
            case "4":
                menuBoo("");
                break;
            case "5":
                menuI("");
                break;
            case "6":
                menuCondicional("");
                break;
            case "7":
                menuCadenas("");
                break;
            case "8":
                menuSeparadores("");
                break;
            case "9":
                menuPO("");
                break;
            case "10":
                me("");
                break;
            default:
                System.out.println("Ingrese un número válido");
                c = me("");
                break;
        }
        return c;
    }

    public static double menuBoo(String mensaje) throws IOException {
        printMenuHeader("Operaciones Booleanas");
        System.out.println("1: AND");
        System.out.println("2: OR");
        System.out.println("3: NOT");
        System.out.println("4: Verificar Igualdad");
        System.out.println("5: Verificar Diferencia");
        System.out.println("6: Volver al menú principal");

        
        printMenuFooter();
        
        double c = 0;
        String x = leerString("Elige una opción: ");
        switch (x) {
            case "1":
                andOperation("Realizando operación AND...");
                break;
            case "2":
                orOperation("Realizando operación OR...");
                break;
            case "3":
                notOperation("Realizando operación NOT...");
                break;
            case "4":
                equalsOperation("Comprobando si dos valores booleanos son iguales...");
                break;
            case "5":
                notEqualsOperation("Comprobando si dos valores booleanos son diferentes...");
                break;
            case "6":
                me("");
                break;
            default:
                System.out.println("Por favor, ingrese un número válido.");
                c = menuBoo("");
                break;
        }
        return c;
    }

    public static double menuI(String mensaje) throws IOException {
        printMenuHeader("Operaciones Incrementales y Aritméticas Combinadas");
        System.out.println("1: Suma con Pre-incremento");
        System.out.println("2: Resta con Pre-decremento");
        System.out.println("3: Multiplicación con Post-incremento");
        System.out.println("4: División con Post-decremento");
        System.out.println("5: Módulo con Pre-incremento");
         System.out.println("6: Volver al menú principal");

        printMenuFooter();
        
        double c = 0;
        String opcion = leerString("Elige una opción: ");
        switch (opcion) {
            case "1":
                sumaIncremental("Suma con pre-incremento");
                break;
            case "2":
                restaDecremental("Resta con pre-decremento");
                break;
            case "3":
                multiplicacionPostIncremental("Multiplicación con post-incremento");
                break;
            case "4":
                divisionPostDecremental("División con post-decremento");
                break;
            case "5":
                moduloIncremental("Módulo con pre-incremento");
                break;
            case "6":
                me("");
                break;
            default:
                System.out.println("Opción no válida. Intente de nuevo.");
                menuI(mensaje);
                break;
        }
        return c;
    }

    public static double menuCondicional(String mensaje) throws IOException {
        printMenuHeader("Operaciones Condicionales");
        System.out.println("1: Operación con Operador Ternario");
        System.out.println("2: Operación con Operador Ternario Booleano");
        System.out.println("3: Volver al menú principal");

        printMenuFooter();
        
        double c = 0;
        String x = leerString("Elige una opción: ");
        switch (x) {
            case "1":
                operadorTernario("");
                break;
            case "2":
                operadorTernarioBooleano("");
                break;
            case "3":
                me("");
                break;
                
            default:
                System.out.println("Ingrese un número válido");
                c = menuCondicional("");
                break;
        }
        return c;
    }

    public static double menuCadenas(String mensaje) throws IOException {
        printMenuHeader("Operaciones con Cadenas");
        System.out.println("1: Concatenación de Cadenas");
        System.out.println("2: Comparar Cadenas");
        System.out.println("3: Comparar Cadenas Ignorando Mayúsculas/Minúsculas");
        System.out.println("4: Volver al menú principal");

        printMenuFooter();
        
        double c = 0;
        String x = leerString("Elige una opción: ");
        switch (x) {
            case "1":
                concatenacion("");
                break;
            case "2":
                comparacion("");
                break;
            case "3":
                comparacionIgnoreCase("");
                break;
            case"4":
                me("");
                break;
                
            default:
                System.out.println("Ingrese un número válido");
                c = menuCadenas("");
                break;
        }
        return c;
    }

    public static double menuSeparadores(String mensaje) throws IOException {
        printMenuHeader("Operaciones con Separadores");
        System.out.println("1: Separar Números con Comas");
        System.out.println("2: Separar Números con Punto y Coma");
        System.out.println("3: Mostrar Números entre Llaves");
        System.out.println("4: Mostrar Números entre Paréntesis");
        System.out.println("5: Mostrar Números entre Corchetes");
        System.out.println("6 Volver al Menú Principal");
        printMenuFooter();
        
        double c = 0;
        String x = leerString("Elige una opción: ");
        switch (x) {
            case "1":
                mostrarComas("");
                break;
            case "2":
                mostrarPuntoYComa("");
                break;
            case "3":
                mostrarLlaves("");
                break;
            case "4":
                mostrarParentesis("");
                break;
            case "5":
                mostrarCorchetes("");
                break;
            case "6":
                me("");
                break;
            default:
                System.out.println("Ingrese un número válido");
                c = menuSeparadores("");
                break;
        }
        return c;
    }

    public static double menuPO(String mensaje) throws IOException {
        printMenuHeader("Operaciones de Prioridad entre Operadores Aritméticos");
        System.out.println("1: (n1 + n2) - n3");
        System.out.println("2: (n1 * n2) / n3");
        System.out.println("3: (n1 + (n2 * n3)) / n4");
        System.out.println("4: (n1 + n2) * n3");
        System.out.println("5: ((n1 + n2) * n3) / n4");
        System.out.println("6: Volver al menú principal");
        printMenuFooter();
        
        double c = 0;
        String x = leerString("Elige una opción: ");
        switch (x) {
            case "1":
                prioridadSumaResta("");
                break;
            case "2":
                prioridadMultiplicacionDivision("");
                break;
            case "3":
                prioridadCombinada("");
                break;
            case "4":
                prioridadParentesis("");
                break;
            case "5":
                prioridadCombinadaParentesis("");
                break;
                
            case "6":
                me("");
                break;
            default:
                System.out.println("Ingrese un número válido");
                c = menuPO("");
                break;
        }
        return c;
    }
}
