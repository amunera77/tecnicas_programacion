/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Util;

import static Operators.arithmetic.*;
import static Operators.Relational.*;
import static Operators.Bits.*;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

/**
 *
 * @author estudiantelis
 */
public class Lectura {
    public static BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
    
    public static int leerInt(String mensaje) throws IOException {
        int dato = 0;
        System.out.println(mensaje);
        try {
            dato = Integer.parseInt(teclado.readLine());
        } catch (NumberFormatException e) {
            System.out.println("Error: Por favor, introduce un número entero válido.");
        }
        return dato;
    }
    
    public static double leerDouble(String mensaje) throws IOException {
        double dato = 0.0;
        System.out.println(mensaje);
        try {
            dato = Double.parseDouble(teclado.readLine());
        } catch (NumberFormatException e) {
            System.out.println("Error: Por favor, introduce un número decimal válido.");
        }
        return dato;
    }
    
    public static float leerFloat(String mensaje) throws IOException {
        float dato = 0.0f;
        System.out.println(mensaje);
        try {
            dato = Float.parseFloat(teclado.readLine());
        } catch (NumberFormatException e) {
            System.out.println("Error: Por favor, introduce un número flotante válido.");
        }
        return dato;
    }
    
    public static String leerString(String mensaje) throws IOException {
        System.out.println(mensaje);
        return teclado.readLine();
    }
    
    public static String leerLinea(String mensaje) throws IOException {
        System.out.println(mensaje);
        return teclado.readLine();
    }
    
    public static boolean leerBoolean(String mensaje) throws IOException {
        boolean dato = false;
        System.out.println(mensaje);
        try {
            dato = Boolean.parseBoolean(teclado.readLine());
        } catch (Exception e) {
            System.out.println("Error: Por favor, introduce 'true' o 'false'.");
        }
        return dato;
    }
}
