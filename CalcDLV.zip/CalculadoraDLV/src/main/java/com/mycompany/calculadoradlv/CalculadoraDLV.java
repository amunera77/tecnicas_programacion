package com.mycompany.calculadoradlv;

import Menus.Menus;
import java.io.IOException;

/**
 *
 * @author estudiantelis
 */
public class CalculadoraDLV {

    public static void main(String[] args) {
        try {
            Menus.me("");
        } catch (IOException e) {
            System.err.println("Error de entrada/salida: " + e.getMessage());
        }
    }
}
